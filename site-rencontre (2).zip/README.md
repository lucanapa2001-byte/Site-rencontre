# Croisons-nous – site de rencontre

Vidéo aléatoire (avec bouton « Suivant »), messages (débloqués dès qu’un like existe), signalement, blocage, filtre de mots, plein écran.
Aucun compte claude.ai n’est nécessaire.

## Tester chez toi

1. Installe Node.js 18 ou plus (https://nodejs.org).
2. Dans ce dossier : `npm install` puis `npm start`.
3. Ouvre http://localhost:3000 dans **deux onglets** (ou deux appareils sur le même réseau) pour essayer.

La caméra ne marche qu’en `localhost` ou en HTTPS.

## Mettre en ligne

1. Choisis un hébergeur qui fait tourner Node.js et gère le WebSocket et le HTTPS (par exemple Render, Railway, Fly.io ou un VPS). Envoie-lui ce dossier ; la commande de démarrage est `npm start`.
2. Prends un nom de domaine et relie-le à l’hébergeur.
3. Pour Google : ajoute ton site dans Google Search Console, vérifie le domaine et demande l’indexation. Le titre et la description sont déjà dans `public/index.html`.

## À savoir avant d’ouvrir au public

- **Vidéo** : le site utilise un serveur public STUN. Certaines connexions (réseaux d’entreprise, certains mobiles) échouent sans serveur TURN. Pour un site sérieux, ajoute un serveur TURN (par exemple coturn) dans `ICE` dans `public/index.html`.
- **Modération** : les signalements sont écrits dans `signalements.log`. Après 3 signalements, l’adresse IP est bannie 24 h (en mémoire : redémarrer le serveur remet à zéro). Complète la liste de mots dans `server.js` (`BAD`). Un filtre ne remplace pas une vraie modération humaine.
- **Genre et attirance** : les deux questions de départ servent à ne montrer que des personnes compatibles (réciproquement). Une personne non genrée voit tous les genres, comme la liste est filtrée dans les deux sens. L’attirance n’est jamais affichée aux autres. Elle reste en mémoire le temps de la visite, mais c’est une donnée sensible au sens du RGPD : si tu la conserves un jour (comptes, base de données), il faudra un consentement explicite.
- **Pas de base de données** : rien n’est conservé. Les profils et les messages disparaissent quand la personne quitte la page.
- **Mineurs** : la case « 18 ans ou plus » ne vérifie rien. Pour un site public, vois comment vérifier l’âge.
- **Légal (France/UE)** : prévois des mentions légales, des conditions d’utilisation et une politique de confidentialité (RGPD), car tu traites des données personnelles et des flux vidéo. Renseigne-toi auprès d’un juriste avant le lancement.
- Derrière un proxy (la plupart des hébergeurs), l’IP vient de l’en-tête `x-forwarded-for`.
