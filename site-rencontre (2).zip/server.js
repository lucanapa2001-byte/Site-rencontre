const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { WebSocketServer } = require("ws");

const PORT = process.env.PORT || 3000;
const PUB = path.join(__dirname, "public");
const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".txt": "text/plain; charset=utf-8" };

// Liste de départ : à compléter selon tes besoins.
const BAD = /\b(branl\w*|pute\w*|salope\w*|encul\w*|viol\w*|nazi\w*|porn\w*|pedo\w*|bite|chatte|nudes?|suce\w*)\b/i;
const bad = (s) => BAD.test(String(s).normalize("NFD").replace(/[\u0300-\u036f]/g, ""));

const BAN_MS = 24 * 3600 * 1000;
const REPORTS_TO_BAN = 3;

const users = new Map();   // id -> {id, ws, ip, name, bio, busy, times}
const likes = new Map();   // id -> Set des id aimés
const blocks = new Map();  // id -> Set des id bloqués
const reportCount = new Map(); // ip -> nombre de signalements
const banned = new Map();  // ip -> timestamp de fin de bannissement

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split("?")[0]);
  if (p === "/") p = "/index.html";
  const f = path.join(PUB, path.normalize(p));
  if (!f.startsWith(PUB)) { res.writeHead(403); return res.end(); }
  fs.readFile(f, (e, d) => {
    if (e) { res.writeHead(404); return res.end("Introuvable"); }
    res.writeHead(200, {
      "Content-Type": TYPES[path.extname(f)] || "application/octet-stream",
      "X-Content-Type-Options": "nosniff",
      "Permissions-Policy": "camera=(self), microphone=(self)"
    });
    res.end(d);
  });
});

const wss = new WebSocketServer({ server, maxPayload: 20000 });

const send = (u, o) => { if (u && u.ws.readyState === 1) u.ws.send(JSON.stringify(o)); };
const isBlocked = (a, b) => (blocks.get(a) && blocks.get(a).has(b)) || (blocks.get(b) && blocks.get(b).has(a));
const hasLiked = (a, b) => !!(likes.get(a) && likes.get(a).has(b));

// Genre et attirance : sert uniquement à proposer des personnes compatibles (jamais montré aux autres).
const GENDERS = ["homme", "femme", "nongenre"];
const ORIENTS = ["hetero", "gay", "lesbienne"];
function validProfile(g, o) {
  if (!GENDERS.includes(g) || !ORIENTS.includes(o)) return false;
  if (g === "homme") return o !== "lesbienne";
  if (g === "femme") return o !== "gay";
  return true;
}
// Genres qui intéressent la personne. Une personne non genrée voit tous les genres (la compatibilité reste réciproque).
function interests(u) {
  if (u.gender === "nongenre") return GENDERS;
  if (u.orient === "hetero") return [u.gender === "homme" ? "femme" : "homme"];
  return [u.gender];
}
const compat = (a, b) => interests(a).includes(b.gender) && interests(b).includes(a.gender);

function listFor(id) {
  const me = users.get(id);
  return [...users.values()]
    .filter((u) => u.name && u.id !== id && !isBlocked(id, u.id) && compat(me, u))
    .map((u) => ({ id: u.id, name: u.name, bio: u.bio, gender: u.gender, busy: u.busy, likedMe: hasLiked(u.id, id) }));
}
function pushLists() {
  users.forEach((u) => { if (u.name) send(u, { t: "list", users: listFor(u.id) }); });
}
function addBlock(a, b) {
  if (!blocks.has(a)) blocks.set(a, new Set());
  blocks.get(a).add(b);
  send(users.get(b), { t: "sig", from: a, k: "bye" });
  send(users.get(a), { t: "sig", from: b, k: "bye" });
}

wss.on("connection", (ws, req) => {
  const ip = (req.headers["x-forwarded-for"] || "").split(",")[0].trim() || req.socket.remoteAddress;
  if ((banned.get(ip) || 0) > Date.now()) { ws.close(4003, "banni"); return; }

  const me = { id: crypto.randomBytes(6).toString("hex"), ws, ip, name: "", bio: "", gender: "", orient: "", busy: false, times: [] };
  users.set(me.id, me);
  send(me, { t: "hello", id: me.id });

  ws.on("message", (raw) => {
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    if (!m || typeof m.t !== "string") return;

    // Limite de débit : 20 messages par 10 secondes.
    const now = Date.now();
    me.times = me.times.filter((x) => now - x < 10000);
    if (me.times.length >= 20) return;
    me.times.push(now);

    if (m.t === "join") {
      const name = String(m.name || "").trim().slice(0, 24);
      const bio = String(m.bio || "").trim().slice(0, 140);
      if (!name || m.adult !== true) return send(me, { t: "error", m: "Pseudo et confirmation de majorité obligatoires." });
      if (!validProfile(m.gender, m.orient)) return send(me, { t: "error", m: "Choisis ton genre et ton attirance (les deux doivent être cohérents)." });
      if (bad(name) || bad(bio)) return send(me, { t: "error", m: "Ce pseudo ou cette description n’est pas accepté(e)." });
      me.name = name; me.bio = bio; me.gender = m.gender; me.orient = m.orient;
      send(me, { t: "joined" });
      return pushLists();
    }
    if (!me.name) return; // il faut d’abord s’inscrire

    const to = users.get(m.to);
    const ok = to && to.name && to.id !== me.id && !isBlocked(me.id, to.id) && compat(me, to);

    if (m.t === "like" && ok) {
      if (!likes.has(me.id)) likes.set(me.id, new Set());
      likes.get(me.id).add(to.id);
      send(to, { t: "like", from: me.id });
      pushLists();
    } else if (m.t === "msg" && ok) {
      if (!(hasLiked(me.id, to.id) || hasLiked(to.id, me.id))) return;
      let text = String(m.text || "").trim().slice(0, 500);
      if (!text) return;
      if (bad(text)) text = "***";
      send(to, { t: "msg", from: me.id, text });
    } else if (m.t === "sig" && ok) {
      send(to, { t: "sig", from: me.id, k: m.k, v: m.v });
    } else if (m.t === "random") {
      const free = [...users.values()].filter((u) => u.name && !u.busy && u.id !== me.id && u.id !== m.avoid && !isBlocked(me.id, u.id) && compat(me, u));
      if (!free.length) return send(me, { t: "nomatch" });
      send(me, { t: "match", to: free[Math.floor(Math.random() * free.length)].id });
    } else if (m.t === "busy") {
      me.busy = !!m.v; pushLists();
    } else if (m.t === "block" && ok) {
      addBlock(me.id, to.id); pushLists();
    } else if (m.t === "report" && ok) {
      const line = JSON.stringify({ date: new Date().toISOString(), de: me.ip, contre: to.ip, pseudo: to.name, bio: to.bio, motif: String(m.reason || "").slice(0, 200) }) + "\n";
      fs.appendFile(path.join(__dirname, "signalements.log"), line, () => {});
      addBlock(me.id, to.id);
      const c = (reportCount.get(to.ip) || 0) + 1;
      reportCount.set(to.ip, c);
      if (c >= REPORTS_TO_BAN) { banned.set(to.ip, Date.now() + BAN_MS); reportCount.set(to.ip, 0); to.ws.close(4003, "banni"); }
      pushLists();
    }
  });

  ws.on("close", () => {
    users.delete(me.id); likes.delete(me.id);
    likes.forEach((s) => s.delete(me.id));
    pushLists();
  });
});

server.listen(PORT, () => console.log("Site lancé sur http://localhost:" + PORT));
